import React from 'react';
import {
  Box, TextField, FormControl, InputLabel, Select, MenuItem, InputAdornment, Tooltip, Typography
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { useDispatch, useSelector } from 'react-redux';
import { setBasicInfo } from '../../store';
import FormNavigation from '../FormNavigation';

export default function BasicInfoForm({
  fields, errors, touched, countryCode, setCountryCode, state, setState, city, setCity,
  countryCodes, states, cities, handleChange, handleBlur, handleStateChange, handleSubmit
}) {
  const dispatch = useDispatch();

  const handleChangeRedux = (e) => {
    const { name, value } = e.target;
    dispatch(setBasicInfo({ [name]: value }));
    if (handleChange) handleChange(e);
  };

  const handleDateChange = (date) => {
    const formattedDate = date ? date.toLocaleDateString('en-GB') : '';
    dispatch(setBasicInfo({ dob: formattedDate }));
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box component="form" onSubmit={handleSubmit} sx={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '28px 40px',
        alignItems: 'start',
        mb: 2
      }}>
        <TextField
          label="Full name"
          required
          name="fullName"
          value={fields.fullName}
          onChange={handleChangeRedux}
          onBlur={() => handleBlur('fullName')}
          error={Boolean(touched.fullName && errors.fullName)}
          helperText={touched.fullName && errors.fullName}
          sx={{ width: 400, background: '#fff' }}
          inputProps={{ style: { fontSize: 16 } }}
        />
        <TextField
          label="Email address"
          required
          name="email"
          value={fields.email}
          onChange={handleChangeRedux}
          onBlur={() => handleBlur('email')}
          error={Boolean(touched.email && errors.email)}
          helperText={touched.email && errors.email}
          sx={{ width: 400, background: '#fff' }}
          inputProps={{ style: { fontSize: 16 } }}
        />
        <Box sx={{ display: 'flex', width: 400 }}>
          <FormControl sx={{ minWidth: 90, mr: 1 }}>
            <InputLabel>+91</InputLabel>
            <Select
              value={countryCode}
              label="+91"
              onChange={e => setCountryCode(e.target.value)}
              IconComponent={KeyboardArrowDownIcon}
              sx={{ fontSize: 16 }}
            >
              {countryCodes.map((c) => (
                <MenuItem key={c.code} value={c.code}>{c.code}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            label="Phone number"
            required
            name="phone"
            value={fields.phone}
            onChange={handleChangeRedux}
            onBlur={() => handleBlur('phone')}
            error={Boolean(touched.phone && errors.phone)}
            helperText={touched.phone && errors.phone}
            sx={{ flex: 1, background: '#fff' }}
            inputProps={{ style: { fontSize: 16 } }}
          />
        </Box>
        <DatePicker
          label="Date of birth"
          value={fields.dob ? new Date(fields.dob.split('/').reverse().join('-')) : null}
          onChange={handleDateChange}
          renderInput={(params) => (
            <TextField
              {...params}
              required
              error={Boolean(touched.dob && errors.dob)}
              helperText={touched.dob && errors.dob}
              onBlur={() => handleBlur('dob')}
              sx={{ width: 400, background: '#fff' }}
              inputProps={{ 
                ...params.inputProps,
                style: { fontSize: 16 }
              }}
            />
          )}
          maxDate={new Date()}
          sx={{
            '& .MuiInputBase-root': {
              fontSize: 16,
            },
          }}
        />
        <FormControl required error={Boolean(touched.state && errors.state)} sx={{ width: 400, background: '#fff' }}>
          <InputLabel>State</InputLabel>
          <Select
            value={state}
            label="State"
            onChange={handleStateChange}
            onBlur={() => handleBlur('state')}
            IconComponent={KeyboardArrowDownIcon}
            sx={{ fontSize: 16 }}
          >
            {states.map((s) => (
              <MenuItem key={s} value={s}>{s}</MenuItem>
            ))}
          </Select>
          {touched.state && errors.state && (
            <Typography variant="caption" color="error">{errors.state}</Typography>
          )}
        </FormControl>
        <FormControl required error={Boolean(touched.city && errors.city)} sx={{ width: 400, background: '#fff', position: 'relative' }}>
          <InputLabel>City</InputLabel>
          <Tooltip title={state ? '' : 'City options will load once a state is selected.'} arrow placement="top">
            <span>
              <Select
                value={city}
                label="City"
                onChange={e => setCity(e.target.value)}
                onBlur={() => handleBlur('city')}
                IconComponent={KeyboardArrowDownIcon}
                disabled={!state}
                sx={{ fontSize: 16 }}
              >
                {state && cities.map((c) => (
                  <MenuItem key={c} value={c}>{c}</MenuItem>
                ))}
              </Select>
            </span>
          </Tooltip>
          <InfoOutlinedIcon sx={{ position: 'absolute', right: 36, top: 18, color: '#bdbdbd', fontSize: 20 }} />
          {touched.city && errors.city && (
            <Typography variant="caption" color="error">{errors.city}</Typography>
          )}
        </FormControl>
        <TextField
          label="Add LinkedIn url"
          name="linkedin"
          value={fields.linkedin}
          onChange={handleChangeRedux}
          placeholder="linkedin.com/in/johndoe"
          helperText="Used to verify your professional presence. Please ensure the URL is accurate and publicly viewable."
          sx={{ width: 840, gridColumn: '1 / span 2', background: '#fff' }}
          inputProps={{ style: { fontSize: 16 } }}
        />
        <Box sx={{ gridColumn: '1 / span 2', pt: 2, mt: 2 }}>
          <FormNavigation
            onBack={() => {}}
            onNext={handleSubmit}
            showBack={true}
            showNext={true}
            backDisabled={true}
            nextDisabled={Object.keys(errors).length > 0}
          />
        </Box>
      </Box>
    </LocalizationProvider>
  );
} 